<?php
    class Urlmodel extends CI_Model
    {
        
		public function url_insert($data)
		{
// Inserting in Table(students) of Database(college)
         $this->db->insert('short_url', $data);
		 
		
		 
        }
		
		function show_url($data)
		{
		
           $this->db->select('*');
           $this->db->from('short_url');
           $this->db->where('short_url', $data);
           $query = $this->db->get();
		  $sql =$this->db->last_query();
		   
           $result = $query->result();
		  // var_dump($result);
          return $result;
		  
		  
        }
		
			
			
        
    }
?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Url extends CI_Controller {

public function __construct() {
	parent::__construct();

// Load form helper library
	$this->load->helper('form');
	$this->load->helper('url');
	$this->load->database();
// Load form validation library
	$this->load->library('form_validation');

// Load session library
	$this->load->library('session');

 //Load database
$this->load->model('urlmodel');
}

	public function index()
	{
	
		$id = $this->uri->segment(3);
		
		$this->load->view('index');
	}
	
	public function create_url()
	{
	$url=$this->input->post('pg_url');
 	$short_url=substr(md5($url.mt_rand()),0,8);
		$data = array(
'page_name' => $this->input->post('page'),
'original_url' => $this->input->post('pg_url'),
'short_url' => $short_url

);

$this->urlmodel->url_insert($data);

redirect('url/createshort/'.$short_url);
	}
	public function createshort()
	{
	
		$id = $this->uri->segment(3);
		
		$this->load->view('shorturl');
	}

		public function geturl() 
	{
        //$this->load->model("testmodel");    
        
		$url=$this->input->post('url');
        $short_url=substr($url,27);
		
        $data = $this->urlmodel->show_url($short_url);
		$path = $data[0]->original_url;
		if(!empty($data))
		{
			echo $path;
			redirect($path);
		}
		else{
		redirect('url/createshort/'.$url);
		}
		//print_r($data);
        //$this->load->view('home', $data);
   
	}
}

<?php

?>
<!DOCTYPE html>
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta charset="utf-8">
<title>Untitled Document</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Untitled Document</title>
<link href="<?php echo base_url(); ?>css/bootstrap.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>css/bootstrap_002.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url(); ?>css/font-awesome.css">

<link rel="stylesheet" href="<?php echo base_url(); ?>css/font-awesome_002.css">
<link href="<?php echo base_url(); ?>css/menu.css" rel="stylesheet">
<script src="<?php echo base_url(); ?>js/jquery_002.js"></script>
<script src="<?php echo base_url(); ?>js/bootstrap.js" type="text/javascript"></script>
<style>
.navbar-inverse .navbar-nav>li>a {
    color: #fff;
    font-weight: bold;
}
@media (max-width:768px){
.navbar-inverse{ background-color:#ccc !important; color:#808080 !important;}

.navbar-inverse .navbar-collapse, .navbar-inverse .navbar-form

{
border:none;	}
.navbar-nav
{
	float:left !important;
	
	}
.navbar-inverse .navbar-nav>li>a
{
	color:#333;
}
}
#parallelogram { width: 180px; 
height: 100px; 
-webkit-transform: 
skew(20deg); -moz-transform: 
skew(20deg); 
-o-transform: skew(20deg); 
background: red; }


#burst-8 { background: red; width: 80px; height: 80px; position: relative; text-align: center; -webkit-transform: rotate(20deg); -moz-transform: rotate(20deg); -ms-transform: rotate(20deg); -o-transform: rotate(20eg); } #burst-8:before { content: ""; position: absolute; top: 0; left: 0; height: 80px; width: 80px; background: red; -webkit-transform: rotate(135deg); -moz-transform: rotate(135deg); -ms-transform: rotate(135deg); -o-transform: rotate(135deg); } 

</style>
<style>
.container { width:85%;  }
#defaultmenu
{
	background-color:#00264D; !important;
	
}
.dropdown w3_megamenu-fw
{
color:#FFFFFF !important;
}
.dropdown-menu
{
background-color:#00264D; !important;
}
.dropdown-toggle
{
color:#FFFFFF !important;
}
 dropdown-toggle > a:hover
{
color:#000 !important;
 background-color: #000 !important;
}
dropdown open
{
color:#000 !important;
}
/*.navbar-nav > .open > a:hover {
    color: #555;
   background-color: #000 !important;
}*/
.navbar-default .navbar-nav>.open>a:hover {
    color: #fff;
    background-color: #930 !important;
}
body,td,th {
	font-size: larger;
}
</style>

</head>

<body>

<!--head section strat-->
<section style=" ">
<div class="container-fluid">

<div class="row" style="background-color:#DCE6F7;">
<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12" >

</div>

<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12" >


</div>
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12" style="color:#0000;">

<div id="header">
            <div id="logo"><a href="index.html"><img src="images/logo.png" alt="" title="" border="0" /></a></div></br></br></br></br>
			
</div>
</div>
</div>
</div>
</sectionn>
<section style="border:1px dotted #888888;">
<div class="container-fluid">

<div class="row">
<div class="col-lg-12 col-md-12 col-sm-4 col-xs-4" >

</div>
</div>
</div>
</sectionn>

<style>
.carousel-navbar {
 
text-align:center;
 
}
 
.carousel-nav {
 
border: 1px solid #ccc;
 
display:inline-block;
 
padding: <span style="color: black; font-family: Consolas; font-size: 14px; background-color: white;">15px 10px</span>;
 
color:black;
width: 20px;
 
}
 
.carousel-nav:hover{
 
border:1px solid #777;
 
}
 
.carousel-nav.current {
 
background-color:#ccc;
 
}
</style>


<script>
dsettings: {
 magnifyby: 3, //default increase factor of enlarged image
 duration: 500, //default duration of animation, in millisec
 mgopacity: 0.2 //opacify of original image when enlarged image overlays it
},
cursorcss: 'url(magnify.cur), -moz-zoom-in', //Value for CSS's 'cursor' attribute, added to original image

</script>
<style> 
#breaking {
    border: 2px solid #a1a1a1;
    padding: 10px 40px; 
    background: green;
    width: 100%;
    border-radius: 15px;
    color: #fff;
    font-weight:bold;
    text-align: center;
}
</style>

<section >
<div class="container-fluid">
<div class="row">
<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12" style="float:left;">
<div style="border:1px dotted #888888; height:985px;">
<div style="height:50px; " id="breaking">&nbsp;</div>
<ul class="list-unstyled" style="margin-left:8px;">
 <li style="margin-top:10px;"><a href="" style="color:red; text-decoration:none; ">
  
Home
</a>
  </li>
   <li style="margin-top:10px;"><a href="" style="color:red; text-decoration:none; ">
  
About Us
</a>
  </li>
  <li style="margin-top:10px;"><a href="" style="color:red; text-decoration:none; ">
  
Contact 
</a>
  </li>
   
</ul>


</div>

</div>
<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12" style="float:left ;border:1px dotted #888888;">
 <div class="row">&nbsp;</div>
  
   <div class="row">
 <div class="form-group col-lg-6" ><b style = "color: cornflowerblue;">Welcome to  Home Page</b></div>
  <hr>
 
  
  </div>
 <label for="exampleInputFile">&nbsp;</label>
  
   
   </div>
</div>

</div>

</div></div>
</section>


<section style="width:100%; background-color:black; height:150px;">

<div class="container">
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
footer
</div></div></div>
</section>
</div>
<img style="cursor: pointer; opacity: 1; position: absolute; left: 0px; top: 0px; visibility: hidden; border: 1px solid gray;" id="sarah2" src="../Untitled Document_files/image-0003.jpg" class="magnify img-responsive " height="1048" width="680"><img style="cursor: pointer; position: absolute; left: 0px; top: 0px; visibility: hidden; border: 1px solid gray;" id="sarah2" src="../Untitled Document_files/image-0003.jpg" class="magnify img-responsive " height="1048" width="680"></body></html>